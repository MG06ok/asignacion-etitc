<?php
include('app/config.php');
include('layout/sesion.php');
?>

<!DOCTYPE html>
<html lang="es">
<?php include 'includes/head.php'; ?>
<body>
  <?php include 'includes/navbar.php'; ?>


<div class="container mt-5 mb-5">
    <h2 class="text-center mb-4">Registrar Docentes - Clases</h2>
    <a class="btn btn-secondary" href="registrar.php" role="button">Menú</a>
    <a class="btn" href="aregistro.php" role="button" style="background-color: #8fbe29">Aulas</a>
    <a class="btn" href="eregistro.php" role="button" style="background-color: #8fbe29">Grupos</a>

    <form method="POST" action="app/controllers/docente/registrar_docente.php">
      <div class="mb-3">
        <label for="grupo" class="form-label">Nombre del docente</label>
        <input type="text" name="name" class="form-control" required/>
        <div class="form-text">Nombre completo.</div>
      </div>

      <div class="mb-3">
        <label for="grupo" class="form-label">Asignaturas</label>
        <input type="text" name="asignatura" class="form-control" required/>
      </div>

         <!-- Tabla de Horario -->
        <table class="table table-bordered text-center">
          <thead class="table-dark">
            <tr>
              <th>Día</th>
              <th>Hora de inicio</th>
              <th>Hora de fin</th>
            </tr>
          </thead>
          <tbody>
            <!-- Lunes a Sábado -->
            <tr><td>Lunes</td><td><input type="time" class="form-control" name="inicio-lunes"></td><td><input type="time" class="form-control" name="fin-lunes"></td></tr>
            <tr><td>Martes</td><td><input type="time" class="form-control" name="inicio-martes"></td><td><input type="time" class="form-control" name="fin-martes"></td></tr>
            <tr><td>Miércoles</td><td><input type="time" class="form-control" name="inicio-miercoles"></td><td><input type="time" class="form-control" name="fin-miercoles"></td></tr>
            <tr><td>Jueves</td><td><input type="time" class="form-control" name="inicio-jueves"></td><td><input type="time" class="form-control" name="fin-jueves"></td></tr>
            <tr><td>Viernes</td><td><input type="time" class="form-control" name="inicio-viernes"></td><td><input type="time" class="form-control" name="fin-viernes"></td></tr>
            <tr><td>Sábado</td><td><input type="time" class="form-control" name="inicio-sabado"></td><td><input type="time" class="form-control" name="fin-sabado"></td></tr>
          </tbody>
        </table>
    <button type="submit" class="btn text-white" style="background-color: rgb(69, 99, 5)">Registrar Docente</button>
    </form>
  </div>
</div> 

<script>
document.querySelector('form').addEventListener('submit', function(e) {
  const dias = ['lunes', 'martes', 'miercoles', 'jueves', 'viernes', 'sabado'];
  let tieneClase = false;
  let errorDia = null;

  dias.forEach(dia => {
    const inicio = document.querySelector(`[name="inicio-${dia}"]`).value;
    const fin = document.querySelector(`[name="fin-${dia}"]`).value;

    if ((inicio && !fin) || (!inicio && fin)) {
      errorDia = dia.charAt(0).toUpperCase() + dia.slice(1);
    }

    if (inicio && fin) {
      tieneClase = true;
    }
  });

  if (errorDia) {
    e.preventDefault();
    Swal.fire({
      icon: 'warning',
      title: 'Horario incompleto',
      text: `El día ${errorDia} tiene una hora incompleta. Por favor completa tanto la hora de inicio como la de fin.`,
      confirmButtonText: 'Entendido'
    });
    return;
  }

  if (!tieneClase) {
    e.preventDefault();
    Swal.fire({
      icon: 'error',
      title: 'Sin clases asignadas',
      text: 'Debes asignar al menos una clase (con hora de inicio y fin) para registrar al docente.',
      confirmButtonText: 'Ok'
    });
  }
});
</script>

</body>
</html>
