<?php
session_start();
?>

<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <title>Registro - ETITC</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body style="background-image: url('images/fondo_etitc.jpg'); background-size: cover; background-position: center;"
      class="d-flex align-items-center justify-content-center vh-100">

  <?php
    if (isset($_SESSION['mensaje'])) {
      $respuesta = $_SESSION['mensaje'];
      $icon = $_SESSION['icon'];
  ?>
      <script>
        Swal.fire({
          title: "<?php echo $respuesta; ?>",
          icon: "<?php echo $icon; ?>",
          confirmButtonColor: "#9DACFF"
        });
      </script>
  <?php
      unset($_SESSION['mensaje']);
    }
  ?>

  <div class="card shadow rounded-4 p-4" style="width: 100%; max-width: 450px;">

    <div class="text-center mb-3">
      <img src="images/logo-etitc.png" alt="Logo ETITC" style="width: 120px;">
    </div>

    <h3 class="text-center mb-4">Crear Cuenta</h3>

    <form action="app/controllers/register/create.php" method="post">

      <div class="mb-3">
        <label class="form-label">Nombre Completo</label>
        <input type="text" name="nombre" class="form-control" placeholder="Ingrese su nombre completo" required>
      </div>

      <div class="mb-3">
        <label class="form-label">Correo Institucional</label>
        <input type="email" name="email" class="form-control" placeholder="usuario@etitc.edu.co" required>
        <div class="form-text">Sólo se permiten correos institucionales</div>
      </div>

      <div class="mb-3">
        <label class="form-label">Contraseña</label>
        <div class="input-group">
          <input type="password" name="password_user" id="password1" class="form-control" required minlength="6">
          <button type="button" class="btn btn-outline-secondary" onclick="togglePassword('password1','icon1')">
            <i class="fa fa-eye" id="icon1"></i>
          </button>
        </div>
        <div class="form-text">Mínimo 6 caracteres</div>
      </div>

      <div class="mb-3">
        <label class="form-label">Repetir Contraseña</label>
        <div class="input-group">
          <input type="password" name="password_repeat" id="password2" class="form-control" required minlength="6">
          <button type="button" class="btn btn-outline-secondary" onclick="togglePassword('password2','icon2')">
            <i class="fa fa-eye" id="icon2"></i>
          </button>
        </div>
      </div>

      <button type="submit" class="btn w-100 mt-2" style="background-color:#8fbe29; color:white;" onclick="return validar()">
        Registrarse
      </button>
    </form>

    <div class="text-center mt-3">
      <small>¿Ya tienes cuenta?
        <a href="index.php" class="fw-bold" style="color:#8fbe29;">Inicia sesión</a>
      </small>
    </div>

  </div>

  <script>
    function togglePassword(inputId, iconId) {
      const input = document.getElementById(inputId);
      const icon = document.getElementById(iconId);
      if (input.type === "password") {
        input.type = "text";
        icon.classList.replace("fa-eye", "fa-eye-slash");
      } else {
        input.type = "password";
        icon.classList.replace("fa-eye-slash", "fa-eye");
      }
    }

    function validar() {
      const p1 = document.getElementById("password1").value;
      const p2 = document.getElementById("password2").value;

      if (p1.length < 6) {
        Swal.fire({
          title: "La contraseña debe tener al menos 6 caracteres",
          icon: "error",
          confirmButtonColor: "#9DACFF"
        });
        return false;
      }

      if (p1 !== p2) {
        Swal.fire({
          title: "Las contraseñas no coinciden",
          icon: "error",
          confirmButtonColor: "#9DACFF"
        });
        return false;
      }
      
      // Validar que sea correo institucional
      const email = document.querySelector('input[name="email"]').value;
      if (!email.endsWith('@itc.edu.co')) {
        Swal.fire({
          title: "Debe usar un correo institucional (@itc.edu.co)",
          icon: "error",
          confirmButtonColor: "#9DACFF"
        });
        return false;
      }
      
      return true;
    }
  </script>

</body>

</html>