<?php
include('app/config.php');
include('layout/sesion.php');

$sql = "SELECT * FROM aulas";
$result = $pdo->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<?php include 'includes/head.php'; ?>

<body style="background-image: url('images/etitc.jpg'); background-size: cover; background-position: center; background-repeat: no-repeat; min-height: 100vh;">
  <?php include 'includes/navbar.php'; ?>
  <?php
  if (isset($_SESSION['mensaje'])) {
    $respuesta = $_SESSION['mensaje']; ?>
    <script>
      Swal.fire({
        position: "top-end",
        icon: "success",
        title: "<?php echo $respuesta; ?>",
        showConfirmButton: false,
        timer: 3000
      });
    </script>
  <?php
    unset($_SESSION['mensaje']);
  }
  ?>
  <div class="table-responsive">
    <div class="container mt-4">
    <h1 class="mb-4" style="color:rgb(255, 255, 255)">Listado de Aulas</h1>
    <table class="table table-striped table-bordered">
      <thead class="table-dark">
        <tr>
          <th>Código de Aula</th>
          <th>Tipo de Aula</th>
          <th>Capacidad</th>
          <th>Elementos Disponibles</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($aula = $result->fetch(PDO::FETCH_ASSOC)) { ?>
          <tr>
            <td><?= htmlspecialchars($aula['numero_aula']) ?></td>
            <td><?= htmlspecialchars($aula['tipo_aula']) ?></td>
            <td><?= htmlspecialchars($aula['capacidad']) ?></td>
            <td><?= htmlspecialchars($aula['elementos']) ?></td>
          </tr>
        <?php } ?>
      </tbody>
    </table>
  </div>
</div>
</body>

</html>