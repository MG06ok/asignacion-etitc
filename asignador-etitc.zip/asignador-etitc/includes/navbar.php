<!-- navbar.php -->
<nav class="navbar navbar-expand-lg navbar-dark" style="background-color: rgb(69, 99, 5);">
  <div class="container-fluid">
    <!-- Logo e inicio -->
    <a class="navbar-brand d-flex align-items-center" href="#">
      <img src="images/logo-etitc.png" alt="Logo ETITC" width="40" height="40" class="me-2">
      <span class="d-none d-sm-inline">ETITC - Asignación</span>
    </a>

    <!-- Botón responsive -->
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
      aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <!-- Menú colapsable -->
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="index.php">Inicio</a></li>
        <li class="nav-item"><a class="nav-link" href="registrar.php">Registrar</a></li>
        <li class="nav-item"><a class="nav-link" href="aulas.php">Aulas</a></li>
        <li class="nav-item"><a class="nav-link" href="docentes.php">Docentes</a></li>
        <li class="nav-item"><a class="nav-link" href="estudiantes.php">Estudiantes</a></li>
        <li class="nav-item"><a class="nav-link" href="asignaciones.php">Asignaciones</a></li>
        <li class="nav-item">
          <a href="<?php echo $URL; ?>app/controllers/login/cerrar_sesion.php" class="nav-link" style="background-color: #8fbe29; border-radius: 5px;">
            Cerrar sesión
          </a>
        </li>
      </ul>
    </div>
  </div>
</nav>
