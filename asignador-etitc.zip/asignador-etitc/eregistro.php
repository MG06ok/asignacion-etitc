<?php
include('app/config.php');
include('layout/sesion.php');

?>

<!DOCTYPE html>
<html lang="es">
<?php include 'includes/head.php'; ?>
<body>
  <?php include 'includes/navbar.php'; ?>

<div class="container mt-5 mb-5">
    <h2 class="text-center mb-4">Registrar Grupos - Clases</h2>
    <a class="btn btn-secondary" href="registrar.php" role="button">Menú</a>
    <a class="btn" href="aregistro.php" role="button" style="background-color: #8fbe29">Aulas</a>
    <a class="btn" href="dregistro.php" role="button" style="background-color: #8fbe29">Docentes</a>

    <form method="POST" action="app/controllers/estudiantes/registrar_estudiantes.php">
      <!-- Tipo de educación -->
      <div class="mb-3">
        <label for="tipoAula" class="form-label">Tipo de educación</label>
        <select class="form-select" name="tipo_educacion" required>
          <option value="" disabled selected>Seleccione una opción</option>
          <option value="Educación Superior">Educación Superior</option>
          <option value="Educación Básica">Educación Básica</option>
        </select>
      </div>

      <div class="mb-3">
        <label for="name" class="form-label">Grupo</label>
        <input type="text" name="nombre_grupo" class="form-control" id="name" required />
      </div>

      <div class="mb-3">
        <label for="grupo" class="form-label">Cantidad de estudiantes</label>
        <input type="number" class="form-control" name="cantidad_es" placeholder="Cantidad de estudiantes" min="12" max="40">
      </div>  
      <button type="submit" class="btn text-white" style="background-color: rgb(69, 99, 5)">Registrar Grupo</button>
    </form>
</div> 
</body>
</html>