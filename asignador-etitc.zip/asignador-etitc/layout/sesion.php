<?php

session_start();

if (isset($_SESSION['sesion_email'])) {
    $email_session = $_SESSION['sesion_email'];
    $sql = "SELECT us.id_usuario as id_usuario, us.nombre as nombre, us.email as email, rol.rol as rol FROM `tb_usuarios` as us INNER JOIN tb_roles as rol ON us.id_rol = rol.id_rol WHERE email = '$email_session'";
    $query = $pdo->prepare($sql);
    $query->execute();
    $usuarios = $query->fetchAll(PDO::FETCH_ASSOC);
    foreach ($usuarios as $usuario) {
        $id_usuario = $usuario['id_usuario'];
        $nombre = $usuario['nombre'];
        $rol_sesion = $usuario['rol'];
    }

} else {
    header('Location:' . $URL . 'login.php');
    exit;
}
?>
