<?php
include('app/config.php');
include('layout/sesion.php');

// Configurar zona horaria
date_default_timezone_set('America/Bogota');

// Formateador internacional en español
$formatter = new IntlDateFormatter('es_ES', IntlDateFormatter::FULL, IntlDateFormatter::SHORT);
$formatter->setPattern("EEEE, dd 'de' MMMM 'de' yyyy - HH:mm");
?>

<!DOCTYPE html>
<html lang="es">
<?php include 'includes/head.php'; ?>

<body style="background-image: url('images/etitc.jpg'); background-size: cover; background-position: center; background-repeat: no-repeat; min-height: 100vh;">
  <?php include 'includes/navbar.php'; ?>

  <?php
  if (isset($_SESSION['mensaje'])) {
    $respuesta = $_SESSION['mensaje']; ?>
    <script>
      Swal.fire({
        position: "top-end",
        icon: "success",
        title: "<?php echo $respuesta; ?>",
        showConfirmButton: false,
        timer: 3000
      });
    </script>
  <?php
    unset($_SESSION['mensaje']);
  }
  ?>

  <div class="container mt-5 mb-5">
    <h2 class="text-center mb-4" style="color:rgb(255, 255, 255)">Cronogramas de Asignación</h2>

    <div class="text-center mb-4">
      <button class="btn" onclick="mostrar('superior')" style="border: 2px solid #8fbe29; color: #8fbe29;">
        Educación Superior</button>
      <button class="btn" onclick="mostrar('basica')" style="border: 2px solid rgb(255, 255, 255); color: rgb(255, 255, 255);">
        Educación Básica</button>
    </div>

    <!-- EDUCACIÓN SUPERIOR -->

    <div class="table-responsive">
    <div id="superior" class="cronograma">
      <h4 class="text" style="color: #8fbe29">Educación Superior (2pm - 10pm)</h4>
      <table class="table table-bordered table-striped">
        <thead class="table-dark">
          <tr>
            <th>Fecha y hora</th>
            <th>Grupo</th>
            <th>Aula</th>
            <th>Docente</th>
            <th>Asignatura</th>
            <th>Tipo Asignatura</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $consulta = $pdo->query("SELECT ac.*, 
                                          d.nombre_docente AS nombre_docente,
                                          a.numero_aula AS nombre_aula,
                                          e.nombre_grupo AS nombre_grupo
                                   FROM asignaciones_clases ac
                                   LEFT JOIN tb_docentes d ON ac.id_docente = d.id
                                   LEFT JOIN aulas a ON ac.id_aula = a.id
                                   LEFT JOIN estudiantes e ON ac.grupo_estudiantes = e.id
                                   WHERE ac.tipo_educacion = 'Educación Superior'
                                   ORDER BY ac.fecha_hora ASC");

          while ($fila = $consulta->fetch(PDO::FETCH_ASSOC)) {
            $fecha = new DateTime($fila['fecha_hora']);
            $fecha_formateada = ucfirst($formatter->format($fecha));
            echo "<tr>
                    <td>{$fecha_formateada}</td>
                    <td>{$fila['nombre_grupo']}</td>
                    <td>{$fila['nombre_aula']}</td>
                    <td>{$fila['nombre_docente']}</td>
                    <td>{$fila['asignatura']}</td>
                    <td>{$fila['tipo_asignatura']}</td>
                  </tr>";
          }
          ?>
        </tbody>
      </table>
    </div>
    </div>

    <!-- EDUCACIÓN BÁSICA -->

    <div class="table-responsive">
<div id="basica" class="cronograma d-none">
      <h4 class="text" style="color: rgb(255, 255, 255)">Educación Básica (6am - 2pm)</h4>
      <table class="table table-bordered table-striped">
        <thead class="table-dark">
          <tr>
            <th>Fecha y hora</th>
            <th>Grupo</th>
            <th>Aula</th>
            <th>Docente</th>
            <th>Asignatura</th>
            <th>Tipo Asignatura</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $consulta = $pdo->query("SELECT ac.*, 
                                          d.nombre_docente AS nombre_docente,
                                          a.numero_aula AS nombre_aula,
                                          e.nombre_grupo AS nombre_grupo
                                   FROM asignaciones_clases ac
                                   LEFT JOIN tb_docentes d ON ac.id_docente = d.id
                                   LEFT JOIN aulas a ON ac.id_aula = a.id
                                   LEFT JOIN estudiantes e ON ac.grupo_estudiantes = e.id
                                   WHERE ac.tipo_educacion = 'Educación Básica'
                                   ORDER BY ac.fecha_hora ASC");

          while ($fila = $consulta->fetch(PDO::FETCH_ASSOC)) {
            $fecha = new DateTime($fila['fecha_hora']);
            $fecha_formateada = ucfirst($formatter->format($fecha));
            echo "<tr>
                    <td>{$fecha_formateada}</td>
                    <td>{$fila['nombre_grupo']}</td>
                    <td>{$fila['nombre_aula']}</td>
                    <td>{$fila['nombre_docente']}</td>
                    <td>{$fila['asignatura']}</td>
                    <td>{$fila['tipo_asignatura']}</td>
                  </tr>";
          }
          ?>
        </tbody>
      </table>
    </div>
    </div>
  </div>

  <script>
    function mostrar(tipo) {
      document.getElementById('superior').classList.add('d-none');
      document.getElementById('basica').classList.add('d-none');
      document.getElementById(tipo).classList.remove('d-none');
    }
  </script>
</body>

</html>