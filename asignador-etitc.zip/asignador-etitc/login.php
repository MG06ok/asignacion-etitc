<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <title>Login - ETITC</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <!-- Librería sweetalert2 -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body style="background-image: url('images/chicas.jpg'); background-size: cover; background-position: center;" class="d-flex align-items-center justify-content-center vh-100">

  <?php
    session_start();
    if (isset($_SESSION['mensaje'])) {
      $respuesta = $_SESSION['mensaje'];
      $icon = $_SESSION['icon']; ?>
      <script>
        Swal.fire({
          title: "<?php echo $respuesta; ?>",
          icon: "<?php echo $icon; ?>",
          confirmButtonColor: "#9DACFF",
          draggable: true
        });
      </script>
    <?php
      unset($_SESSION['mensaje']);
    }
  ?>

  <div class="card shadow rounded-4 p-4" style="width: 100%; max-width: 400px;">
    
    <div class="text-center mb-4">
      <img src="images/logo-etitc.png" alt="Logo ETITC" style="width: 120px;">
    </div>

    <h3 class="text-center mb-4">Iniciar Sesión</h3>

    <form action="app/controllers/login/ingreso.php" method="post">
      <div class="mb-3">
        <label for="username" class="form-label">Correo</label>
        <input type="email" class="form-control" name="email" placeholder="Ingrese su usuario" required>
      </div>

      <div class="mb-3">
        <label for="password" class="form-label">Contraseña</label>
        <div class="input-group">
          <input type="password" class="form-control" name="password_user" id="password" placeholder="Ingrese su contraseña" required>
          <button type="button" class="btn btn-outline-secondary" onclick="togglePassword()">
            <i class="fa fa-eye" id="toggleIcon"></i>
          </button>
        </div>
      </div>

      <button type="submit" class="btn w-100" style="background-color: #8fbe29; color: white;">Ingresar</button>
    </form>

    <!-- Apartado para ir al registro -->
    <div class="text-center mt-3">
  <small>¿No tienes cuenta?  
    <a href="register.php" class="fw-bold" style="color: #8fbe29;">Regístrate aquí</a>
  </small>
</div>


  </div>

  <script>
    function togglePassword() {
      const passwordInput = document.getElementById("password");
      const toggleIcon = document.getElementById("toggleIcon");
      if (passwordInput.type === "password") {
        passwordInput.type = "text";
        toggleIcon.classList.remove("fa-eye");
        toggleIcon.classList.add("fa-eye-slash");
      } else {
        passwordInput.type = "password";
        toggleIcon.classList.remove("fa-eye-slash");
        toggleIcon.classList.add("fa-eye");
      }
    }
  </script>

</body>

</html>
