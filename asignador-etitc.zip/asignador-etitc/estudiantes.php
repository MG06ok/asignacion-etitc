<?php
include('app/config.php');
include('layout/sesion.php');

$sql = "SELECT * FROM estudiantes";
$result = $pdo->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<?php include 'includes/head.php'; ?>
<body style="background-image: url('images/personas_etitc.jpg'); background-size: cover; background-position: center; background-repeat: no-repeat; min-height: 100vh;">
  <?php include 'includes/navbar.php'; ?>
  <?php
if (isset($_SESSION['mensaje'])) {
    $respuesta = $_SESSION['mensaje']; ?>
    <script>
        Swal.fire({
            position: "top-end",
            icon: "success",
            title: "<?php echo $respuesta; ?>",
            showConfirmButton: false,
            timer: 3000
        });
    </script>
<?php
    unset($_SESSION['mensaje']);
}
?>
 <div class="container mt-4">
    <h1 class="mb-4" style="color:rgb(118, 184, 115)">Grupos de Estudiantes</h1>
    <div class="mb-3">
        <a class="btn btn-lg w-100" href="edbasica.php" role="button" style="background-color: #8fbe29">Educación Básica</a>
      </div>
    <div class="mb-3">
        <a class="btn btn-lg w-100" href="edsuperior.php" role="button" style="background-color: #8fbe29">Educación Superior</a>
      </div>
  </div>
</body>
</html>
