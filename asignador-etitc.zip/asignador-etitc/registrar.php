<?php
include('app/config.php');
include('layout/sesion.php');
?>

<!DOCTYPE html>
<html lang="es">
<?php include 'includes/head.php'; ?>
<body style="background-image: url('images/fondo_etitc.jpg'); background-size: cover; background-position: center; background-repeat: no-repeat; min-height: 100vh;">
  <?php include 'includes/navbar.php'; ?>

  <style>
    .btn-group-custom {
      max-width: 800px;
      margin: auto;
    }
  </style>

  <div class="container mt-5 text-center">
    <h2 class="mb-4"  style="color:rgb(255, 255, 255)">Registrar Recursos - Clases</h2>
    
    <div class="row btn-group-custom">
      <div class="col-md-4 mb-3">
        <a class="btn btn-lg w-100" href="aregistro.php" role="button" style="background-color: #8fbe29">Aulas</a>
      </div>
      <div class="col-md-4 mb-3">
        <a class="btn btn-lg w-100" href="dregistro.php" role="button" style="background-color: #8fbe29">Docentes</a>
      </div>
      <div class="col-md-4 mb-3">
        <a class="btn btn-lg w-100" href="eregistro.php" role="button" style="background-color: #8fbe29">Grupos</a>
      </div>
    </div>

    <div class="mt-4">
      <a class="btn btn-secondary" href="registrar.php" role="button">Menú</a>
    </div>
  </div>

</body>
</html>
