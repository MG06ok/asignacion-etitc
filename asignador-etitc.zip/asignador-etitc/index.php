<?php
include('app/config.php');
include('layout/sesion.php');

// Obtener docentes
$consulta_docente = $pdo->query("SELECT id, nombre_docente FROM tb_docentes");
$docente = $consulta_docente->fetchAll(PDO::FETCH_ASSOC);

// Obtener aulas
$consulta_aula = $pdo->query("SELECT id, numero_aula, capacidad, elementos FROM aulas");
$aula = $consulta_aula->fetchAll(PDO::FETCH_ASSOC);

// Obtener estudiantes
$consulta_estudiantes = $pdo->query("SELECT id, tipo_educacion, nombre_grupo, cantidad_es FROM estudiantes");
$estudiantes = $consulta_estudiantes->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<?php include 'includes/head.php'; ?>

<body>
  <?php include 'includes/navbar.php'; ?>

  <?php

  if (isset($_SESSION['mensaje'])) {
    $respuesta = $_SESSION['mensaje']; ?>
    <script>
      Swal.fire({
        position: "top-end",
        icon: "success",
        title: "<?php echo $respuesta; ?>",
        showConfirmButton: false,
        timer: 3000
      });
    </script>
  <?php
    unset($_SESSION['mensaje']);
  }

  ?>

  <div class="container mt-5 mb-5">
    <h1 class="mb-4">Asignación de Clases</h1>
    <form id="formAsignacion" method="POST" action="app/controllers/asignacion_clase/registrar_clase.php">
      <div class="mb-3">
        <label for="tipoAula" class="form-label">Tipo de educación</label>
        <select class="form-select" id="tipo_educacion" name="tipo_educacion" required>
          <option value="" disabled selected>Seleccione una opción</option>
          <option value="Educación Superior">Educación Superior</option>
          <option value="Educación Básica">Educación Básica</option>
        </select>
      </div>

      <div class="mb-3">
        <label for="grupo" class="form-label">Grupo de Estudiantes</label>
        <select class="form-select" name="grupo_estudiantes" id="grupo_estudiantes" disabled required>
          <option value="" disabled selected>Seleccionar grupo</option>
          <?php foreach ($estudiantes as $estudiante): ?>
            <option
              value="<?= $estudiante['id'] ?>"
              data-tipo="<?= $estudiante['tipo_educacion'] ?>">
              <?= htmlspecialchars($estudiante['nombre_grupo']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="mb-3">
        <label for="docente" class="form-label">Docente</label>
        <select class="form-select" name="docente" required>
          <option value="" disabled selected>Seleccionar docente</option>
          <?php foreach ($docente as $docente): ?>
            <option value="<?= $docente['id'] ?>"><?= htmlspecialchars($docente['nombre_docente']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="mb-3">
        <label for="asignatura" class="form-label">Asignatura</label>
        <input type="text" class="form-control" id="asignatura" name="asignatura" required>
      </div>

      <div class="mb-3">
        <label for="tipoAsignatura" class="form-label">Tipo de Asignatura</label>
        <select class="form-select" name="tipo_asignatura" required>
          <option value="" disabled selected>Seleccione una opción</option>
          <option value="Teórica">Teórica</option>
          <option value="Practica">Practica</option>
          <option value="Educación Básica">Teórica-Practica</option>
        </select>
      </div>

      <div class="mb-3">
        <label for="aula" class="form-label">Aula</label>
        <select class="form-select" id="aula" name="aula" required>
          <option value="" disabled selected>Seleccionar aula</option>
          <?php foreach ($aula as $aula): ?>
            <option
              value="<?= $aula['id'] ?>"
              data-elementos="<?= htmlspecialchars($aula['elementos']) ?>">
              <?= htmlspecialchars($aula['numero_aula']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="mb-3">
        <label class="form-label">Accesorios del Aula</label>
        <div id="accesorios"></div>
        <input type="hidden" id="elementos" name="elementos">
      </div>

      <div class="mb-3">
        <label for="fecha" class="form-label">Fecha y hora</label>
        <input type="datetime-local" class="form-control" id="fecha" name="fecha" required>
        <div class="form-text">Educación Básica: 6am - 2pm, Educación Superior: 2pm - 10pm.</div>
      </div>

      <button type="submit" class="btn text-white" style="background-color: rgb(69, 99, 5)">Asignar Clase </button>
    </form>
  </div>

  <script>
    document.addEventListener('DOMContentLoaded', function() {
      const selectAula = document.getElementById('aula');
      const contenedorAccesorios = document.getElementById('accesorios');

      selectAula.addEventListener('change', function() {
        const opcionSeleccionada = selectAula.options[selectAula.selectedIndex];
        const elementos = opcionSeleccionada.getAttribute('data-elementos');

        // Limpiar contenido anterior
        contenedorAccesorios.innerHTML = '';

        if (elementos) {
          const lista = elementos.split(',').map(e => e.trim());

          lista.forEach(function(elemento) {
            const div = document.createElement('div');
            div.classList.add('form-check');

            const input = document.createElement('input');
            input.classList.add('form-check-input');
            input.type = 'checkbox';
            input.disabled = true;
            input.checked = true;
            input.id = elemento;

            const label = document.createElement('label');
            label.classList.add('form-check-label');
            label.htmlFor = elemento;
            label.textContent = elemento;

            div.appendChild(input);
            div.appendChild(label);
            contenedorAccesorios.appendChild(div);
          });
        } else {
          contenedorAccesorios.innerHTML = '<em>Este aula no tiene elementos registrados.</em>';
        }
      });
    });
  </script>

  <script>
  document.addEventListener('DOMContentLoaded', function () {
    const tipoEducacionSelect = document.getElementById('tipo_educacion');
    const grupoSelect = document.getElementById('grupo_estudiantes');

    // Guarda todas las opciones originales (menos la opción por defecto)
    const opcionesOriginales = Array.from(grupoSelect.options).filter(opt => opt.value !== '');

    // Deshabilita el select al inicio
    grupoSelect.disabled = true;

    tipoEducacionSelect.addEventListener('change', function () {
      const tipoSeleccionado = tipoEducacionSelect.value;

      // Limpia todas las opciones
      grupoSelect.innerHTML = '';

      // Agrega de nuevo la opción por defecto
      const defaultOption = document.createElement('option');
      defaultOption.value = '';
      defaultOption.disabled = true;
      defaultOption.selected = true;
      defaultOption.textContent = 'Seleccionar grupo';
      grupoSelect.appendChild(defaultOption);

      // Filtra y agrega solo las opciones que coincidan con el tipo de educación
      let hayOpciones = false;
      opcionesOriginales.forEach(option => {
        const tipo = option.getAttribute('data-tipo');
        if (tipo === tipoSeleccionado) {
          grupoSelect.appendChild(option);
          hayOpciones = true;
        }
      });

      // Habilita el select si hay opciones disponibles, si no, lo deja deshabilitado
      grupoSelect.disabled = !hayOpciones;
    });
  });
</script>



</body>

</html>