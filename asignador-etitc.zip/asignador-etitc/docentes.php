<?php
include('app/config.php');
include('layout/sesion.php');

$sql = "SELECT * FROM tb_docentes";
$result = $pdo->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<?php include 'includes/head.php'; ?>
<body style="background-image: url('images/etitc.jpg'); background-size: cover; background-position: center; background-repeat: no-repeat; min-height: 100vh;">
<?php include 'includes/navbar.php'; ?>
<?php
if (isset($_SESSION['mensaje'])) {
    $respuesta = $_SESSION['mensaje']; ?>
    <script>
        Swal.fire({
            position: "top-end",
            icon: "success",
            title: "<?php echo $respuesta; ?>",
            showConfirmButton: false,
            timer: 3000
        });
    </script>
<?php
    unset($_SESSION['mensaje']);
}
?>
  <div class="container mt-4">
  <h1 class="mb-4" style="color:rgb(255, 255, 255)">Docentes</h1>

  <div class="table-responsive">
    <table class="table table-bordered table-striped align-middle">
      <thead class="table-dark text-center">
        <tr>
          <th>Nombre</th>
          <th>Asignatura</th>
          <th>Lunes</th>
          <th>Martes</th>
          <th>Miércoles</th>
          <th>Jueves</th>
          <th>Viernes</th>
          <th>Sábado</th>
        </tr>
      </thead>
      <tbody class="text-center">
        <?php while ($docente = $result->fetch(PDO::FETCH_ASSOC)) { ?>
          <tr>
            <td><?= htmlspecialchars($docente['nombre_docente']) ?></td>
            <td><?= htmlspecialchars($docente['asignaturas']) ?></td>
            <td>
              <?= ($docente['inicio_lunes'] && $docente['fin_lunes']) ?
                  $docente['inicio_lunes'] . " - " . $docente['fin_lunes'] : '—' ?>
            </td>
            <td>
              <?= ($docente['inicio_martes'] && $docente['fin_martes']) ?
                  $docente['inicio_martes'] . " - " . $docente['fin_martes'] : '—' ?>
            </td>
            <td>
              <?= ($docente['inicio_miercoles'] && $docente['fin_miercoles']) ?
                  $docente['inicio_miercoles'] . " - " . $docente['fin_miercoles'] : '—' ?>
            </td>
            <td>
              <?= ($docente['inicio_jueves'] && $docente['fin_jueves']) ?
                  $docente['inicio_jueves'] . " - " . $docente['fin_jueves'] : '—' ?>
            </td>
            <td>
              <?= ($docente['inicio_viernes'] && $docente['fin_viernes']) ?
                  $docente['inicio_viernes'] . " - " . $docente['fin_viernes'] : '—' ?>
            </td>
            <td>
              <?= ($docente['inicio_sabado'] && $docente['fin_sabado']) ?
                  $docente['inicio_sabado'] . " - " . $docente['fin_sabado'] : '—' ?>
            </td>
          </tr>
        <?php } ?>
      </tbody>
    </table>
  </div>
</div>

</body>
</html>
