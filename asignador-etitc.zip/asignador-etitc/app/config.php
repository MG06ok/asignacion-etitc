<?php
define('SERVIDOR','localhost');
define('USUARIO','root');
define('PASSWORD','');
define('BD','asignador_etitc'); 

//define('SERVIDOR','sql303.infinityfree.com');
//define('USUARIO','if0_39114436');
//define('PASSWORD','Hi88pin8Ykme');
//define('BD','if0_39114436_asignador_etitc');


$servidor = "mysql:dbname=".BD.";host=".SERVIDOR;

try {
    $pdo = new PDO($servidor, USUARIO, PASSWORD, array(PDO::MYSQL_ATTR_INIT_COMMAND=>"SET NAMES utf8"));
} catch (PDOException $e){
    die("Error a conectar a la base de datos: " . $e->getMessage());
}

$URL = "http://localhost/asignador-etitc/";
//$URL = "https://asignadoretitc.rf.gd/";

date_default_timezone_set("America/Bogota");
$fecha_hora = date('Y-m-d H:i:s');

?>