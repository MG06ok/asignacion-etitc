<?php
session_start();
include('../../config.php');

// Verificar si todos los campos están presentes
$campos_requeridos = ['nombre', 'email', 'password_user', 'password_repeat'];
foreach ($campos_requeridos as $campo) {
    if (!isset($_POST[$campo]) || empty($_POST[$campo])) {
        $_SESSION['mensaje'] = "ERROR: Todos los campos son obligatorios";
        $_SESSION['icon'] = 'error';
        header('Location: ' . $URL . '/registro');
        exit();
    }
}

$nombre = trim($_POST['nombre']);
$email = trim($_POST['email']);
$password_user = $_POST['password_user'];
$password_repeat = $_POST['password_repeat'];

// Validar que sea correo institucional
if (!preg_match('/@itc\.edu\.co$/i', $email)) {
    $_SESSION['mensaje'] = "ERROR: Solo se permiten correos institucionales @itc.edu.co";
    $_SESSION['icon'] = 'error';
    header('Location: ' . $URL . '/registro');
    exit();
}

// Validar formato de correo
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $_SESSION['mensaje'] = "ERROR: El formato del correo no es válido";
    $_SESSION['icon'] = 'error';
    header('Location: ' . $URL . '/registro');
    exit();
}

// Validar longitud de contraseña
if (strlen($password_user) < 6) {
    $_SESSION['mensaje'] = "ERROR: La contraseña debe tener al menos 6 caracteres";
    $_SESSION['icon'] = 'error';
    header('Location: ' . $URL . '/registro');
    exit();
}

// Validar que las contraseñas coincidan
if ($password_user !== $password_repeat) {
    $_SESSION['mensaje'] = "ERROR: Las contraseñas no coinciden";
    $_SESSION['icon'] = 'error';
    header('Location: ' . $URL . '/registro');
    exit();
}

// Verificar si el correo ya está registrado
try {
    $consulta = $pdo->prepare("SELECT COUNT(*) AS total FROM tb_usuarios WHERE email = :email");
    $consulta->bindParam(':email', $email);
    $consulta->execute();
    $resultado = $consulta->fetch(PDO::FETCH_ASSOC);

    if ($resultado['total'] > 0) {
        $_SESSION['mensaje'] = "ERROR: El correo ya está registrado. Intente con otro.";
        $_SESSION['icon'] = 'error';
        header('Location: ' . $URL . '/registro');
        exit();
    }
} catch (PDOException $e) {
    $_SESSION['mensaje'] = "ERROR: Problema al verificar el correo";
    $_SESSION['icon'] = 'error';
    header('Location: ' . $URL . '/registro');
    exit();
}

// Encriptar contraseña
$password_hash = password_hash($password_user, PASSWORD_DEFAULT);

// Obtener fecha y hora actual
$fecha_hora = date('Y-m-d H:i:s');

// Insertar usuario (asumiendo que tu tabla tiene estos campos)
try {
    // Si tu tabla tb_usuarios tiene id_rol, asigna un valor por defecto (ej: 2 para usuario normal)
    $id_rol = 2; // Ajusta según tu sistema de roles
    
    $sentencia = $pdo->prepare("INSERT INTO tb_usuarios 
            (nombre, email, password_user, id_rol, fyh_creacion) 
    VALUES (:nombre, :email, :password_user, :id_rol, :fyh_creacion)");
    
    $sentencia->bindParam(':nombre', $nombre);
    $sentencia->bindParam(':email', $email);
    $sentencia->bindParam(':password_user', $password_hash);
    $sentencia->bindParam(':id_rol', $id_rol);
    $sentencia->bindParam(':fyh_creacion', $fecha_hora);
    
    if ($sentencia->execute()) {
        $_SESSION['mensaje'] = "¡Registro exitoso! Ahora puedes iniciar sesión";
        $_SESSION['icon'] = 'success';
        header('Location: ' . $URL . '/login.php');
        exit();
    } else {
        throw new Exception("Error al ejecutar la consulta");
    }
} catch (Exception $e) {
    $_SESSION['mensaje'] = "ERROR: No se pudo registrar el usuario. " . $e->getMessage();
    $_SESSION['icon'] = 'error';
    header('Location: ' . $URL . '/registro');
    exit();
}
?>