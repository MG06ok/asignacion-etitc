<?php
include('../../config.php'); // conexión a la BD

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $numero_aula = $_POST['numero_aula'];
    $tipo_aula = $_POST['tipo_aula'];
    $capacidad = $_POST['capacidad'];
    $elementos_array = $_POST['elementos'] ?? [];

    if (!is_array($elementos_array)) {
        $elementos_array = [$elementos_array]; // lo convierte en array si vino como string
    }
    $elementos = implode(', ', $elementos_array);

    $sql = "INSERT INTO aulas (numero_aula, tipo_aula, capacidad, elementos)
                VALUES (:numero_aula, :tipo_aula, :capacidad, :elementos)";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':numero_aula' => $numero_aula,
        ':tipo_aula' => $tipo_aula,
        ':capacidad' => $capacidad,
        ':elementos' => $elementos

    ]);

    session_start();
    $_SESSION['mensaje'] = "Aula registrada correctamente";
    header('Location: ' . $URL . 'aulas.php');
}
