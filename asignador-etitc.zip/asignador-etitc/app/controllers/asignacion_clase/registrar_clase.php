<?php
include('../../config.php');

$tipo_educacion = $_POST['tipo_educacion'];
$grupo = $_POST['grupo_estudiantes'];
$id_docente = $_POST['docente'];
$asignatura = $_POST['asignatura'];
$tipo_asignatura = $_POST['tipo_asignatura'];
$id_aula = $_POST['aula'];
$fecha_hora = $_POST['fecha'];

$sql = "INSERT INTO asignaciones_clases 
(tipo_educacion, grupo_estudiantes, id_docente, asignatura, tipo_asignatura, id_aula, fecha_hora)
VALUES (?, ?, ?, ?, ?, ?, ?)";

$sentencia = $pdo->prepare($sql);
$sentencia->execute([$tipo_educacion, $grupo, $id_docente, $asignatura, $tipo_asignatura, $id_aula, $fecha_hora]);

session_start();
$_SESSION['mensaje'] = "Clase asignada con éxito";
header('Location: ' . $URL . 'asignaciones.php');

?>