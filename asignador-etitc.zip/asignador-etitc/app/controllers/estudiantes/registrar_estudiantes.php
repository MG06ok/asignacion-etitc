<?php
include('../../config.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre_grupo = $_POST['nombre_grupo'];
    $cantidad_es = $_POST['cantidad_es'];
    $tipo_educacion= $_POST['tipo_educacion'];


        $sql = "INSERT INTO estudiantes (nombre_grupo, cantidad_es, tipo_educacion)
                VALUES (:nombre_grupo, :cantidad_es, :tipo_educacion)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':nombre_grupo' => $nombre_grupo,
            ':cantidad_es' => $cantidad_es,
            ':tipo_educacion' => $tipo_educacion


        ]);

        session_start();
        $_SESSION['mensaje'] = "Grupo registrado correctamente";
        header("Location: " . $URL . "estudiantes.php");
    } 
?>
