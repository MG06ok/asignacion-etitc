<?php
include('../../config.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre_docente = $_POST['name'];
    $asignaturas = $_POST['asignatura'];

    $dias = ['lunes', 'martes', 'miercoles', 'jueves', 'viernes', 'sabado'];
    $horarios = [];
    $tieneClase = false;

    foreach ($dias as $dia) {
        $inicio = $_POST["inicio-$dia"] ?? null;
        $fin = $_POST["fin-$dia"] ?? null;

        // Si solo uno de los dos está lleno → error
        if ((!empty($inicio) && empty($fin)) || (empty($inicio) && !empty($fin))) {
            echo "<script>alert('Debes completar la hora de inicio y fin del mismo día ($dia) o dejar ambos vacíos.'); history.back();</script>";
            exit;
        }

        // Si ambos están llenos, se cuenta como clase válida
        if (!empty($inicio) && !empty($fin)) {
            $tieneClase = true;
        }

        $horarios["inicio_$dia"] = $inicio;
        $horarios["fin_$dia"] = $fin;
    }

    if (!$tieneClase) {
        echo "<script>alert('Debe asignar al menos una clase (con hora de inicio y fin) para registrar al docente.'); history.back();</script>";
        exit;
    }

    // Guardar en BD
    $sql = "INSERT INTO tb_docentes (
        nombre_docente, asignaturas,
        inicio_lunes, fin_lunes,
        inicio_martes, fin_martes,
        inicio_miercoles, fin_miercoles,
        inicio_jueves, fin_jueves,
        inicio_viernes, fin_viernes,
        inicio_sabado, fin_sabado
    ) VALUES (
        :nombre_docente, :asignaturas,
        :inicio_lunes, :fin_lunes,
        :inicio_martes, :fin_martes,
        :inicio_miercoles, :fin_miercoles,
        :inicio_jueves, :fin_jueves,
        :inicio_viernes, :fin_viernes,
        :inicio_sabado, :fin_sabado
    )";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':nombre_docente' => $nombre_docente,
        ':asignaturas' => $asignaturas,
        ':inicio_lunes' => $horarios['inicio_lunes'],
        ':fin_lunes' => $horarios['fin_lunes'],
        ':inicio_martes' => $horarios['inicio_martes'],
        ':fin_martes' => $horarios['fin_martes'],
        ':inicio_miercoles' => $horarios['inicio_miercoles'],
        ':fin_miercoles' => $horarios['fin_miercoles'],
        ':inicio_jueves' => $horarios['inicio_jueves'],
        ':fin_jueves' => $horarios['fin_jueves'],
        ':inicio_viernes' => $horarios['inicio_viernes'],
        ':fin_viernes' => $horarios['fin_viernes'],
        ':inicio_sabado' => $horarios['inicio_sabado'],
        ':fin_sabado' => $horarios['fin_sabado'],
    ]);

    session_start();
    $_SESSION['mensaje'] = "Se registró de manera correcta el docente";
    header('Location: '. $URL . 'docentes.php');
}
?>