<?php
// Asegúrate de que no haya espacios o saltos de línea antes de <?php
include('../../config.php'); // Ajusta la ruta según tu estructura real

session_start();

// Destruye todas las variables de sesión
$_SESSION = array();

// Borra la cookie de sesión (opcional pero recomendado)
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params["path"],
        $params["domain"],
        $params["secure"],
        $params["httponly"]
    );
}

// Destruye la sesión
session_destroy();

// Redirige al login (ajusta 'login.php' al nombre real de tu archivo)
header("Location: " . $URL . "login.php");
exit(); // ¡Importante para evitar ejecución adicional!
?>