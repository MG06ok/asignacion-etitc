<?php
session_start();
include('../../config.php');

// Verificar si los campos están presentes
if (!isset($_POST['email']) || !isset($_POST['password_user']) || 
    empty($_POST['email']) || empty($_POST['password_user'])) {
    
    $_SESSION['mensaje'] = "ERROR: Todos los campos son obligatorios";
    $_SESSION['icon'] = "error";
    header('Location: ' . $URL . 'login.php');
    exit();
}

$email = trim($_POST['email']);
$password_user = $_POST['password_user'];

try {
    // Usar consultas preparadas para evitar inyección SQL
    $sql = "SELECT * FROM `tb_usuarios` WHERE email = :email";
    $query = $pdo->prepare($sql);
    $query->bindParam(':email', $email);
    $query->execute();
    
    // Obtener un solo resultado (fetch en lugar de fetchAll)
    $usuario = $query->fetch(PDO::FETCH_ASSOC);
    
    if ($usuario) {
        // Verificar la contraseña usando password_verify
        // Esto compara la contraseña ingresada con el hash almacenado en la BD
        if (password_verify($password_user, $usuario['password_user'])) {
            
            // Iniciar variables de sesión
            $_SESSION['sesion_email'] = $usuario['email'];
            $_SESSION['sesion_nombre'] = $usuario['nombre'];
            $_SESSION['sesion_id'] = $usuario['id_usuario'];
            
            // Verificar si existe el campo id_rol
            if (isset($usuario['id_rol'])) {
                $_SESSION['sesion_rol'] = $usuario['id_rol'];
            }
            
            // Mensaje de bienvenida
            $_SESSION['mensaje'] = "Bienvenido/a al sistema " . $usuario['nombre'];
            $_SESSION['icon'] = "success";
            
            // Redirigir al index
            header('Location: ' . $URL . 'index.php');
            exit();
            
        } else {
            // Contraseña incorrecta
            $_SESSION['mensaje'] = "ERROR: Correo o contraseña incorrectos";
            $_SESSION['icon'] = "error";
            header('Location: ' . $URL . 'login.php');
            exit();
        }
    } else {
        // Usuario no encontrado
        $_SESSION['mensaje'] = "ERROR: Correo o contraseña incorrectos";
        $_SESSION['icon'] = "error";
        header('Location: ' . $URL . 'login.php');
        exit();
    }
    
} catch (PDOException $e) {
    // Manejo de errores de base de datos
    error_log("Error en login: " . $e->getMessage());
    
    $_SESSION['mensaje'] = "ERROR: Problema en el sistema. Intente más tarde";
    $_SESSION['icon'] = "error";
    header('Location: ' . $URL . 'login.php');
    exit();
}
?>