<?php
include('app/config.php');
include('layout/sesion.php');

$sql = "SELECT * FROM estudiantes WHERE tipo_educacion='Educación Superior'";
$result = $pdo->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<?php include 'includes/head.php'; ?>
<body>
  <?php include 'includes/navbar.php'; ?>

   <div class="container mt-4">
    <h1 class="mb-4">Grupos de Estudiantes</h1>
    <div class="mb-3">
        <a class="btn btn-lg w-100" href="edbasica.php" role="button" style="background-color: #8fbe29">Educación Básica</a>
      </div>
    <h1 class="mb-4">Educación Superior</h1>
    <div class="table-responsive">
      <table class="table table-striped table-bordered">
        <thead class="table-dark">
          <tr>
            <th>Nombre del Grupo</th>
            <th>Cantidad de Estudiantes</th>
          </tr>
        </thead>
         <tbody>
         <?php while ($estudiantes = $result->fetch(PDO::FETCH_ASSOC)) { ?>
        <tr>
          <td><?= htmlspecialchars($estudiantes['nombre_grupo']) ?></td>
          <td><?= htmlspecialchars($estudiantes['cantidad_es']) ?></td>
        </tr>
        <?php } ?>
      </tbody>
      </table>
    </div>
  </div>
</body>
</html>
