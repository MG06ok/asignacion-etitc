<?php
include('app/config.php');
include('layout/sesion.php');
?>

<!DOCTYPE html>
<html lang="es">
<?php include 'includes/head.php'; ?>
<body>
  <?php include 'includes/navbar.php'; ?>

 <div class="container mt-5 mb-5">
    <h2 class="text-center mb-4">Registrar Aulas - Clases</h2>
    <a class="btn btn-secondary" href="registrar.php" role="button">Menú</a>
    <a class="btn" href="dregistro.php" role="button" style="background-color: #8fbe29">Docentes</a>
    <a class="btn" href="eregistro.php" role="button" style="background-color: #8fbe29">Grupos</a>

    <form method="POST" action="app/controllers/aula/registrar_aula.php">

        <!-- Número de aula -->
        <div class="mb-3">
          <label for="numeroAula" class="form-label">Número o Código del Aula</label>
          <input type="text" class="form-control" name="numero_aula" placeholder="Ej: B-204" required >
        </div>

        <!-- Tipo de aula -->
        <div class="mb-3">
          <label for="tipoAula" class="form-label">Tipo de Aula</label>
          <select class="form-select" name="tipo_aula" required>
            <option value="" disabled selected>Seleccione una opción</option>
            <option value="salon">Salón</option>
            <option value="laboratorio">Laboratorio</option>
            <option value="auditorio">Auditorio</option>
            <option value="otro">Otro</option>
          </select>
        </div>

        <!-- Capacidad del aula -->
        <div class="mb-3">
          <label for="capacidad" class="form-label">Capacidad (estudiantes)</label>
          <input type="number" class="form-control" name="capacidad" min="12" max="40" placeholder="Ej: 30" required>
          <div class="form-text">Debe ser entre 12 y 40 estudiantes.</div>
        </div>

        <!-- Elementos disponibles -->
        <div class="mb-3">
          <label class="form-label">Elementos Disponibles</label>
          <div class="form-check">
            <input class="form-check-input" type="checkbox" name="elementos[]" value="Televisor">
            <label class="form-check-label" for="televisor">Televisor</label>
          </div>
          <div class="form-check">
            <input class="form-check-input" type="checkbox" name="elementos[]" value="Video Beam">
            <label class="form-check-label" for="videobeam">Video Beam</label>
          </div>
          <div class="form-check">
            <input class="form-check-input" type="checkbox" name="elementos[]" value="Pantalla">
            <label class="form-check-label" for="pantalla">Pantalla</label>
          </div>
          <div class="form-check">
            <input class="form-check-input" type="checkbox" name="elementos[]" value="Computadores">
            <label class="form-check-label" for="computadores">Computadores</label>
          </div>
        </div>

        <!-- Botón -->
        <div class="d-grid">
          <button type="submit" class="btn text-white" style="background-color: rgb(69, 99, 5)">Registrar Aula</button>
      </form>
</div> 
</body>
</html>
